---
name: Feature request
about: Suggest a feature
title: "[FEATURE] "
labels: feature
---

## Problem to solve

## Proposed solution

## User benefit

## Acceptance criteria
