---
name: Bug report
about: Report an application or calculation defect
title: "[BUG] "
labels: bug
---

## Summary

## Steps to reproduce

## Expected result

## Actual result

## Input data and units
Do not include confidential or personal data.

## Environment
