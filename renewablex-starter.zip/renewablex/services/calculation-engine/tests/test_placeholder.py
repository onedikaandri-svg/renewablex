def test_placeholder():
    # Replace with formula-level tests before accepting calculation changes.
    assert 1000 * 1500 == 1_500_000
