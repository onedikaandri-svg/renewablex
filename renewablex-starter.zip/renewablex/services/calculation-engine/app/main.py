from fastapi import FastAPI
from pydantic import BaseModel, Field
from typing import Literal

app = FastAPI(
    title="RenewableX Calculation Engine",
    version="0.1.0",
    description="Preliminary PV energy and unlevered project-finance calculations."
)

class PVInput(BaseModel):
    capacity_kwp: float = Field(gt=0)
    specific_yield_kwh_per_kwp_year: float = Field(gt=0)
    degradation_fraction_per_year: float = Field(ge=0, lt=1)
    lifetime_years: int = Field(ge=1, le=40)
    capex_amount: float = Field(ge=0)
    annual_opex_amount: float = Field(ge=0)
    tariff_per_kwh: float = Field(ge=0)
    discount_rate_fraction: float = Field(gt=-1)

@app.get("/health")
def health():
    return {"status": "ok", "service": "renewablex-calculation-engine"}

@app.post("/v1/pv/preliminary")
def preliminary_pv(data: PVInput):
    year1 = data.capacity_kwp * data.specific_yield_kwh_per_kwp_year
    annual = []
    cash_flows = [-data.capex_amount]
    cumulative = -data.capex_amount

    annual.append({
        "year": 0, "energy_kwh": 0, "revenue": 0,
        "opex": 0, "cash_flow": -data.capex_amount,
        "cumulative_cash_flow": cumulative
    })

    for year in range(1, data.lifetime_years + 1):
        energy = year1 * ((1 - data.degradation_fraction_per_year) ** (year - 1))
        revenue = energy * data.tariff_per_kwh
        cash_flow = revenue - data.annual_opex_amount
        cumulative += cash_flow
        cash_flows.append(cash_flow)
        annual.append({
            "year": year,
            "energy_kwh": round(energy, 3),
            "revenue": round(revenue, 2),
            "opex": round(data.annual_opex_amount, 2),
            "cash_flow": round(cash_flow, 2),
            "cumulative_cash_flow": round(cumulative, 2)
        })

    import numpy_financial as npf
    npv = sum(cf / ((1 + data.discount_rate_fraction) ** t)
              for t, cf in enumerate(cash_flows))
    irr = npf.irr(cash_flows)
    payback = None
    prior = -data.capex_amount
    for row in annual[1:]:
        current = row["cumulative_cash_flow"]
        if current >= 0:
            period_cf = row["cash_flow"]
            fraction = (-prior / period_cf) if period_cf > 0 else 0
            payback = (row["year"] - 1) + fraction
            break
        prior = current

    return {
        "methodology_version": "0.1.0",
        "energy_method": "manual_specific_yield",
        "year_1_energy_kwh": round(year1, 3),
        "npv_amount": round(float(npv), 2),
        "project_irr_fraction": None if irr is None else round(float(irr), 8),
        "simple_payback_years": None if payback is None else round(payback, 4),
        "payback_status": "not_recovered" if payback is None else "recovered",
        "annual_results": annual,
        "disclaimer": "Preliminary, pre-tax, unlevered estimate. Validate all assumptions independently."
    }
